<?php

$host = "sql302.infinityfree.com";
$usuario = "if0_43228038";
$senha = "Edgar4865";
$banco = "if0_43228038_silenthelp";

$conn = new mysqli($host, $usuario, $senha, $banco);

if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados.");
}

$conn->set_charset("utf8mb4");

?>
